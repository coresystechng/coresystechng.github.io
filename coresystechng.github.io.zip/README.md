# CORE-TECH 

Official Website of CORE-TECH

### Built With

* [Bootstrap CSS](https://getbootstrap.com/)
* [Lordicon](https://lordicon.com/)
* [AOS](https://aos.css/)


### Contributors

* [Collins Okoroafor](https://github.com/collinsduzzy/) - (Project Lead)
* [Trust Onyekwere](https://github.com/trustonyekwere/) - (Contributor)
* [Abdulrazaq Salihu](https://github.com/abdrzqsalihu) - (Contributor)
* [Jenny Rotimi](https://github.com/Jennysgitt) - (Contributor)
* [Bryan Fadipe](https://github.com/bryanfadipe) - (Intern)


